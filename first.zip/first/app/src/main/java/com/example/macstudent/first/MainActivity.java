package com.example.macstudent.first;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.IOException;
import java.util.Iterator;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    OkHttpClient client = new OkHttpClient();
    //user interface variables
    TextView textviewMain;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textviewMain = (TextView) findViewById(R.id.textviewMain);
    }
    public void ButtonPressed(View v){
       // System.out.println();
        Log.d("kamal","person clicked the button");
        //tell the what URL YOU WANT TO GO TO
        String URL = "https://api.coindesk.com/v1/bpi/historical/close.json?currency=BRL&start=2018-01-01&end=2018-01-10";
        final Request request = new Request.Builder().url(URL).build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.d("kamal","Request successfull");
                if(response.isSuccessful()){
                    final String reply = response.body().string();
                    Log.d("kamal",reply);

                    try {
                        JSONObject json = new JSONObject(reply);

                        String disclaimer = json.getString("disclaimer");
                       JSONObject bpi = json.getJSONObject("bpi");
                       Log.d("kamal",disclaimer);
                       Log.d("kamal",bpi.toString());
                        Iterator<String> iterator = bpi.keys();
                        while (iterator.hasNext()){
                            String key = iterator.next();
                            double price = bpi.getDouble(key);
                            Log.d("kamal",key);
                            Log.d("kamal","price");
                            Log.d("kamal",Double.toString(price));
                        }



                    }
                    catch (Exception e){
                        Log.d("kamal","Error while parsing");
                        e.printStackTrace();
                    }
                    /*
                    //output json response to the terminal
                    Log.d("kamal",reply);
                    MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            textviewMain.setText(reply);
                        }
                    });
                    */
                }

            }
        });
    }
}
