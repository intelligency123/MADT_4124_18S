package com.example.macstudent.shake;

import android.content.Context;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.squareup.seismic.ShakeDetector;

public class MainActivity extends AppCompatActivity implements ShakeDetector.Listener{
    boolean lighton = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SensorManager manager = (SensorManager) getSystemService(SENSOR_SERVICE);
        ShakeDetector detector = new ShakeDetector(this);
        detector.start(manager);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void hearShake() {
        Log.d("kamal","phone is shaking");
        Toast.makeText(this,"phone is shaking",Toast.LENGTH_SHORT).show();

        CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        //GET THE CAMERA
        try {
            String cameraID = cameraManager.getCameraIdList()[0];
            //turn on
            if(lighton == false) {
                cameraManager.setTorchMode(cameraID, true);
                Log.d("kamal", "turning light on");
                lighton = true;
            }else{
                cameraManager.setTorchMode(cameraID, false);
                Log.d("kamal", "turning light off");
                lighton = false;
            }
            //turn off
           // cameraManager.setTorchMode(cameraID,false);
        }
        catch (Exception e){
            Log.d("kamal","error while turning on");
           Toast.makeText(this,"error while detecting",Toast.LENGTH_SHORT).show();
        }
    }
}
