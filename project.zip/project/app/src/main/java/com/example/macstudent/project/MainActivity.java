package com.example.macstudent.project;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    SharedPreferences sharep;
    public static final String PREFERENCES_NAME = "kamalpref";
    EditText txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharep = getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
        txt = (EditText)findViewById(R.id.txt);
    }
    public void savedata(View v){
        String name1 = txt.getText().toString();
        Log.d("kamal","save button pressed");
        SharedPreferences.Editor prefEdt = sharep.edit();
        prefEdt.putString("name",name1);
       // prefEdt.putString("name","kamal");
        prefEdt.apply();
        txt.setText("");

    }
    public void fetchdata(View v){
        Log.d("kamal","fetch button pressed");
        String n = sharep.getString("name","");
        Log.d("kamal","got something: "+n);

    }
}
