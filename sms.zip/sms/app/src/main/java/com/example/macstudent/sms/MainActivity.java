package com.example.macstudent.sms;

import android.Manifest;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import  com.karumi.dexter.listener.single.PermissionListener;

public class MainActivity extends AppCompatActivity {
    PermissionListener smspermissionlistener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        createpermissionlistener();
    }
    public void createpermissionlistener(){
        if(smspermissionlistener == null){
            smspermissionlistener = new PermissionListener() {
                @Override
                public void onPermissionGranted(PermissionGrantedResponse response) {
                    SmsManager smsManager = SmsManager.getDefault();

                    smsManager.sendTextMessage("4379896566",null,"hey,what's up?",null,null);
                      Log.d("kamal","sms send");

                }

                @Override
                public void onPermissionDenied(PermissionDeniedResponse response) {
                    Log.d("kamal","person picked deny, i can't send any message");

                }

                @Override
                public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                    token.continuePermissionRequest();

                }
            };
        }
    }
    public void smspressed(View v){
        Log.d("kamal","btn pressed");
        //write code to send an sms
        Dexter.withActivity(this).withPermission(Manifest.permission.SEND_SMS).withListener(smspermissionlistener).check();
    }
}
