package com.example.macstudent.rpsgame;

import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.seismic.ShakeDetector;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements ShakeDetector.Listener{
    boolean lighton = false;
    ImageView rnd_img;
    int count = 0;
    FirebaseDatabase database;
    DatabaseReference root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SensorManager manager = (SensorManager) getSystemService(SENSOR_SERVICE);
        ShakeDetector detector = new ShakeDetector(this);
        detector.start(manager);
        rnd_img = (ImageView)findViewById(R.id.rnd_img);
        database = FirebaseDatabase.getInstance();
        root = database.getReference();
    }


    @Override
    public void hearShake() {
       select();
        Log.d("kamal","phone is shaking");
        Toast.makeText(this,"phone is shaking",Toast.LENGTH_SHORT).show();


    }
    public void select(){
        count++;
        Random rnd = new Random();
        int r = (rnd.nextInt(3));
        if(count == 3) {
            if (r == 0) {
                rnd_img.setImageResource(R.drawable.rock);

                selectimage userName = new selectimage("rock");
                root.child("users").push().setValue(userName);
            } else if (r == 1) {
                rnd_img.setImageResource(R.drawable.paper);
                selectimage userName = new selectimage("paper");
                root.child("users").push().setValue(userName);
            } else if (r == 2) {
                rnd_img.setImageResource(R.drawable.scissor);
                selectimage userName = new selectimage("scissor");
                root.child("users").push().setValue(userName);
            }
            count = 0;
        }
    }
}

