package com.example.macstudent.rpsgame;

public class user {
    public String name;


    public user() {
        // keep this, you need a blank constructor
    }

    public user(String n) {
        this.name = n;

    }

}
