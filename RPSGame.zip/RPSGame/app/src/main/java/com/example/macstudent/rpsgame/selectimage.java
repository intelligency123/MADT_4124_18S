package com.example.macstudent.rpsgame;

public class selectimage {
    String imagename;

    public selectimage(){

    }
    public selectimage(String m){
        this.imagename = m;
    }
}
