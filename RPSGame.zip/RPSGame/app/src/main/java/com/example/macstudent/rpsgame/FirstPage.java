package com.example.macstudent.rpsgame;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FirstPage extends AppCompatActivity implements View.OnClickListener{

    FirebaseDatabase database;
    DatabaseReference root;
    EditText UserName;
    Button start_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_page);
        UserName = findViewById(R.id.UserName);
        start_btn = findViewById(R.id.start_btn);




        //user u = new user("kamal");
       // root.child("users").push().setValue(u);

    }

    @Override
    public void onClick(View v) {
        database = FirebaseDatabase.getInstance();
        root = database.getReference();
       user userName = new user(UserName.getText().toString());
        root.child("users").push().setValue(userName);
        Intent loginIntent = new Intent(this, MainActivity .class);
        startActivity(loginIntent);
    }
}
